"""
intro
"""

from . import scenario
from ._generalized_von_neumann import GeneralizedVonNeumann
from ._simple_unbiased import SimpleUnbiased
from ._dinamica import Dinamica