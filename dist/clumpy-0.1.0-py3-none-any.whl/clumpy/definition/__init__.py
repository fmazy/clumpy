"""
Texte intro au dossier definition
"""

from ._layer import LandUseCoverLayer, FeatureLayer, DistanceToVFeatureLayer, TransitionProbabilityLayers
from . import _transition
from . import _feature
from ._case import Case