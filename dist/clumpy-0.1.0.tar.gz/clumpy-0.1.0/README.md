# Clumpy

build the package :
`python3 setup.py sdist bdist_wheel`

upload on testpypi
`python3 -m twine upload --repository testpypi dist/*`

help about pypi packages
https://packaging.python.org/tutorials/packaging-projects/

install package locally
python setup.py install
